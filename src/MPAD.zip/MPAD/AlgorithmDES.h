/* 
 * File:   AlgorithmDES.h
 * Author: onuryaman
 *
 * Created on December 12, 2011, 11:15 AM
 */

#ifndef ALGORITHMDES_H
#define	ALGORITHMDES_H

// include the AlgorithmInterface header file.
#include "AlgorithmInterface.h";

class AlgorithmDES : public AlgorithmInterface
{
    public:
        std::string encrpyt(std::string rawString, const char* key, int keyLength);
        std::string decrypt(std::string encryptedString, const char* key, int keyLength);
};

// Rename this file DES.H
// DES Encryption and Decryption
// from efgh.com/software

const int DES_KEY_SIZE      =  56;
const int DES_DATA_SIZE     =  64;
const int DES_SBUFFER_SIZE  =  48;
const int DES_ROUNDS =  16;

class des
{
  private:
    const char *xmix(const char *, unsigned char [DES_DATA_SIZE],
      const unsigned char [DES_KEY_SIZE]);
    void encrypt_decrypt(unsigned char [DES_DATA_SIZE], int /* boolean */);
    unsigned char compressed_shifted_key[DES_ROUNDS][DES_SBUFFER_SIZE];
  public:
    void initialize(const unsigned char[DES_KEY_SIZE]);
    void password(const char *);
    void encrypt(unsigned char data[DES_DATA_SIZE])
    {
      encrypt_decrypt(data, 1 /* true */);
    }
    void decrypt(unsigned char data[DES_DATA_SIZE])
    {
      encrypt_decrypt(data, 0 /* false */);
    };
};

#endif	/* ALGORITHMDES_H */